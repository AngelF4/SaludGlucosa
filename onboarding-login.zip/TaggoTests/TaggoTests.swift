//
//  TaggoTests.swift
//  TaggoTests
//
//  Created by Yahir Fuentes on 29/05/25.
//

import Testing
@testable import Taggo

struct TaggoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
