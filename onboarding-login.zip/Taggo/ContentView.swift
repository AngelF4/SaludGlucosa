//
//  ContentView.swift
//  Taggo
//
//  Created by Yahir Fuentes on 29/05/25.
//

import SwiftUI

struct ContentView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var wrongUsername = ""
    @State private var wrongPassword = ""
    @State private var showingLoginScreen = false
    
    @State private var pageIndex = 0 //this would be the first page that shows in the onboarding carousel
    private let pages: [Page] = Page.samplePages
    private let dotAppearance = UIPageControl.appearance()
    
    var body: some View {
        NavigationView{
        TabView(selection: $pageIndex){
            ForEach(pages){ page in
                VStack{
                    Spacer()
                    PageView(page: page)
                    Spacer()
                    
                    if page == pages.last{
                        NavigationLink (destination: Signup()){
                        Text("Sign Up")
                                .frame(maxWidth: 200)
                                .background(Color.gray)
                                .cornerRadius(30)
                        
                        }
                    } else{
                        Button("next", action: incrementPage)
                    }
                    Spacer()
                }
                .tag(page.tag)
            }
        }
        }
        
        .animation(.easeInOut, value: pageIndex)
        .tabViewStyle(.page)
        .indexViewStyle(.page(backgroundDisplayMode: .interactive))
        .onAppear{
            dotAppearance.currentPageIndicatorTintColor = .black
            dotAppearance.pageIndicatorTintColor = .primaryPink
        }
        
    }
    
    func incrementPage(){
        pageIndex += 1
    }
    
    func goToZero(){
        pageIndex = 0
    }
}

#Preview {
    ContentView()
}
