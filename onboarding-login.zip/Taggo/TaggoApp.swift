//
//  TaggoApp.swift
//  Taggo
//
//  Created by Yahir Fuentes on 29/05/25.
//

import SwiftUI

@main
struct TaggoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
