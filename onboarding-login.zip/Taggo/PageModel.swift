//
//  PageModel.swift
//  Taggo
//
//  Created by Yahir Fuentes on 29/05/25.
//

//this page is the "component" for the pages created on the onboarding carousel

import Foundation

struct Page: Identifiable, Equatable {
    let id = UUID()
    var name: String
    var description: String
    var imageUrl: String
    var tag: Int
    
    static var samplePage = Page(name: "taggo", description: "typeshi", imageUrl: "streetstickers", tag: 0)
    
    static var samplePages: [Page] = [
        Page(name: "Bienvenido a la app", description: "ol aoalaolaoaolaoaloaloal", imageUrl: "streetstickers", tag: 0),
    
        Page(name: "Bienvenido a la app", description: "olaolaolaoaloaloaloal", imageUrl: "streetstickers", tag: 1),
    
        Page(name: "Bienvenido a la app", description: "olaoaloaloaloaloalaola", imageUrl: "streetstickers", tag: 2),
    ]
    
}

